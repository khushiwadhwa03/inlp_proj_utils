#IMPORTS
import sys
import numpy as np
import pandas as pd
from collections import Counter
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score
import itertools
from numpy import dot
from numpy.linalg import norm
import time
from sklearn.metrics import f1_score, precision_score, recall_score, hamming_loss
from sklearn.neighbors import KNeighborsClassifier
import pandas as pd
from sklearn.preprocessing import MultiLabelBinarizer, LabelEncoder, OneHotEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.base import BaseEstimator, ClassifierMixin
from skmultilearn.problem_transform import BinaryRelevance, ClassifierChain, LabelPowerset
from sklearn.model_selection import KFold
from sklearn.metrics import multilabel_confusion_matrix

class optimised_KNN:
    def __init__(self, k=3, encoder_type='resnet', distance_metric='euclidean'):
        self.k = k
        self.distance_metric = distance_metric
        self.encoder = 1 if encoder_type == 'vit' else 0

    def fit(self, X, Y):
        self.X_train = X[:, self.encoder]
        self.Y_train = Y

    def calculate_distance(self, x1, x2):
        if self.distance_metric == 'euclidean':
            return np.sqrt(np.sum((x1 - x2) ** 2))
        if self.distance_metric == 'manhattan':
            return np.sum(np.abs(x1 - x2))
        if self.distance_metric == 'cosine':
            distance = np.dot(x1, x2) / (np.linalg.norm(x1) * np.linalg.norm(x2))
            return 1 - distance

    def getClass(self, x):
        distances = [self.calculate_distance(x, x_train) for x_train in self.X_train]
        k_nearest_indices = np.argsort(distances)[:self.k]
        k_nearest_labels = [self.Y_train[i] for i in k_nearest_indices]
        return Counter(k_nearest_labels).most_common(1)[0][0]

    def predict(self, X, Y_actual):
        Y_predictions = [self.getClass(x) for x in X]
        results = {}
        results['f1_weighted'] = f1_score(Y_actual, Y_predictions, average='weighted', zero_division=1)
        results['f1_micro'] = f1_score(Y_actual, Y_predictions, average='micro', zero_division=1)
        results['f1_macro'] = f1_score(Y_actual, Y_predictions, average='macro', zero_division=1)
        results['accuracy'] = accuracy_score(Y_actual, Y_predictions)
        results['precision'] = precision_score(Y_actual, Y_predictions, average='weighted', zero_division=1)
        results['recall'] = recall_score(Y_actual, Y_predictions, average='weighted', zero_division=1)
        return results

if __name__ == "__main__":
    data = np.load("data.npy", allow_pickle = True)
    train_data,test_data = train_test_split(data, test_size=0.2, random_state=2)
    X_train = train_data[:, 1:3]
    y_train = train_data[:, 3]

    #source-chatgpt
    if len(sys.argv) != 2:
        print("Usage:", sys.argv[0], "<test_data_file>")
        sys.exit(1)
    test_data = np.load(sys.argv[1], allow_pickle= True)

    X_test = test_data[:, 2]
    y_test = test_data[:, 3]

    knn = optimised_KNN(k=7, encoder_type='vits', distance_metric='manhattan')
    knn.fit(X_train, y_train)
    result = knn.predict(X_test, y_test)

    result_df = pd.DataFrame(result.items(), columns=['Metric', 'Value'])
    print(result_df)
